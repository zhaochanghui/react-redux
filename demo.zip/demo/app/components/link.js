var React = require('react');
var ReactDOM = require('react-dom');

class Link extends React.Component {
	render() {
		return (
			<a href='http://www.hitecloud.cn'>link</a>
			);
	}
}

module.exports = Link;
